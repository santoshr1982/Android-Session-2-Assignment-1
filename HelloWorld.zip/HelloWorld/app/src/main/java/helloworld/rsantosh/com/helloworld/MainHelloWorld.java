package helloworld.rsantosh.com.helloworld;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainHelloWorld extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_hello_world);

    }
}
